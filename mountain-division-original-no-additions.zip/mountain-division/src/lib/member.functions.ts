import { createServerFn } from '@tanstack/react-start';
import { setResponseHeader } from '@tanstack/react-start/server';
import { z } from 'zod';
import { requireSupabaseAuth } from '@/integrations/supabase/auth-middleware';

export const getMemberData = createServerFn({ method: 'GET' })
 .middleware([requireSupabaseAuth])
 .handler(async ({ context }) => {
  setResponseHeader('Cache-Control', 'no-store');
  const [profile, advice] = await Promise.all([
   context.supabase.from('profiles').select('roblox_username').eq('id', context.userId).single(),
   context.supabase.from('member_recommendations').select('id,recommendation,created_at').eq('user_id', context.userId).order('created_at', { ascending: false }).limit(10),
  ]);
  if (profile.error || advice.error) throw new Error('ไม่สามารถโหลดข้อมูลสมาชิกได้');
  return { profile: profile.data, recommendations: advice.data };
 });

export const updateRobloxName = createServerFn({ method: 'POST' })
 .middleware([requireSupabaseAuth])
 .inputValidator(z.object({ username: z.string().trim().min(3).max(20).regex(/^[A-Za-z0-9_]+$/, 'ใช้ตัวอักษรภาษาอังกฤษ ตัวเลข หรือขีดล่าง 3–20 ตัว') }).strict())
 .handler(async ({ data, context }) => {
  setResponseHeader('Cache-Control', 'no-store');
  const { error } = await context.supabase.from('profiles').update({ roblox_username: data.username, updated_at: new Date().toISOString() }).eq('id', context.userId);
  if (error) return { error: 'บันทึกชื่อ Roblox ไม่สำเร็จ' };
  return { error: null };
 });