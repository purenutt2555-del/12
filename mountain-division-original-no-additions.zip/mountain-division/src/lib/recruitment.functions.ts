import { createServerFn } from '@tanstack/react-start';
import { getRequest, setResponseHeader, setResponseStatus } from '@tanstack/react-start/server';
import { applicantSchema } from './recruitment-schema';
import { requireSupabaseAuth } from '@/integrations/supabase/auth-middleware';
export const recommendUnit = createServerFn({ method: 'POST' })
 .middleware([requireSupabaseAuth])
 .inputValidator(applicantSchema)
 .handler(async ({ data, context }) => {
  setResponseHeader('Cache-Control', 'no-store');
  const apiKey = process.env['LOVABLE_API_KEY'];
  if (!apiKey) return { text: null, error: 'บริการ AI ยังไม่ได้ตั้งค่า กรุณาติดต่อผู้ดูแลเว็บไซต์' };
  const { generateRecommendation } = await import('./recruitment.server');
  const result = await generateRecommendation(getRequest(), apiKey, data);
   if (result.text) {
    const saved = await context.supabase.from('member_recommendations').insert({ user_id: context.userId, interests: data.interests, experience: data.experience, recommendation: result.text });
    if (saved.error) return { text: result.text, error: 'สร้างคำแนะนำแล้ว แต่บันทึกไม่สำเร็จ กรุณาคัดลอกไว้ก่อน' };
   }
  if (result.status !== 200) setResponseStatus(result.status);
  return { text: result.text, error: result.error };
 });
