import { z } from 'zod';
export const applicantSchema = z.object({
 interests: z.string().trim().min(10, 'กรุณาบอกความสนใจอย่างน้อย 10 ตัวอักษร').max(1200, 'ความสนใจยาวเกิน 1,200 ตัวอักษร'),
 experience: z.string().trim().min(10, 'กรุณาบอกประสบการณ์อย่างน้อย 10 ตัวอักษร').max(1800, 'ประสบการณ์ยาวเกิน 1,800 ตัวอักษร'),
}).strict();
export type ApplicantInput = z.infer<typeof applicantSchema>;
