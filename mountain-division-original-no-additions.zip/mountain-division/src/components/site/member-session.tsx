import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import type { User } from '@supabase/supabase-js';
import { useQueryClient } from '@tanstack/react-query';
import { useNavigate, useRouter } from '@tanstack/react-router';
import { supabase } from '@/integrations/supabase/client';
import { lovable } from '@/integrations/lovable';
import { Button } from '@/components/ui/button';
import { LogIn, LoaderCircle } from 'lucide-react';

const MemberContext = createContext<{ user: User | null; ready: boolean; signOut: () => Promise<void> }>({ user: null, ready: false, signOut: async () => {} });
export const useMember = () => useContext(MemberContext);
export function MemberProvider({ children }: { children: ReactNode }) {
 const [user, setUser] = useState<User | null>(null);
 const [ready, setReady] = useState(false);
 const queryClient = useQueryClient();
 const router = useRouter();
 const navigate = useNavigate();
 useEffect(() => {
  let alive = true;
  let revision = 0;
  supabase.auth.getUser().then(({ data }) => { if (alive && revision === 0) { setUser(data.user); setReady(true); } });
  const { data: listener } = supabase.auth.onAuthStateChange((event, session) => {
   if (!['SIGNED_IN', 'SIGNED_OUT', 'USER_UPDATED'].includes(event)) return;
   revision++;
   setUser(session?.user ?? null); setReady(true);
   if (event === 'SIGNED_OUT') { queryClient.cancelQueries(); queryClient.clear(); }
   else queryClient.invalidateQueries();
   router.invalidate();
  });
  return () => { alive = false; listener.subscription.unsubscribe(); };
 }, [queryClient, router]);
 async function signOut() {
  await queryClient.cancelQueries(); queryClient.clear();
  const { error } = await supabase.auth.signOut();
  if (error) throw error;
  await navigate({ to: '/auth', replace: true });
 }
 return <MemberContext.Provider value={{ user, ready, signOut }}>{children}</MemberContext.Provider>;
}
export function GoogleSignIn() {
 const [busy, setBusy] = useState(false);
 const [error, setError] = useState('');
 async function login() {
  setBusy(true); setError('');
  try {
   const result = await lovable.auth.signInWithOAuth('google', { redirect_uri: `${window.location.origin}/auth` });
   if (result.error) setError('เข้าสู่ระบบไม่สำเร็จ กรุณาลองใหม่');
  } catch { setError('ไม่สามารถเชื่อมต่อ Google ได้'); }
  finally { setBusy(false); }
 }
 return <div><Button size="lg" onClick={login} disabled={busy}>{busy ? <LoaderCircle className="animate-spin"/> : <LogIn/>}เข้าสู่ระบบด้วย Google</Button>{error && <p role="alert" className="mt-4 text-sm text-destructive">{error}</p>}</div>;
}