import { useState, useRef, useEffect, type FormEvent } from 'react';
import { useServerFn } from '@tanstack/react-start';
import { Sparkles, ArrowRight, LoaderCircle, Copy, Check, ShieldCheck } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { applicantSchema } from '@/lib/recruitment-schema';
import { recommendUnit } from '@/lib/recruitment.functions';
import { Link } from '@tanstack/react-router';
import { useQueryClient } from '@tanstack/react-query';
import { useMember, GoogleSignIn } from './member-session';
export function RecruitmentAdvisor() {
 const { user, ready } = useMember();
 if (!ready) return <section className="section site-container"><p role="status">กำลังตรวจสอบบัญชี…</p></section>;
 if (!user) return <section className="section border-t"><div className="site-container space-y-6"><div className="eyebrow">AI RECRUITMENT ADVISOR</div><h2 className="section-title">คำแนะนำหน่วยเฉพาะคุณ</h2><p className="text-muted-foreground">เข้าสู่ระบบเพื่อรับและบันทึกคำแนะนำส่วนตัว</p><GoogleSignIn/></div></section>;
 return <SignedInAdvisor key={user.id}/>;
}
function SignedInAdvisor() {
 const queryClient = useQueryClient();
 const call = useServerFn(recommendUnit);
 const [interests,setInterests] = useState('');
 const [experience,setExperience] = useState('');
 const [loading,setLoading] = useState(false);
 const [error,setError] = useState<string|null>(null);
 const [text,setText] = useState<string|null>(null);
 const [copied,setCopied] = useState(false);
 const active = useRef(false);
 const mounted = useRef(true);
 useEffect(()=>{ mounted.current=true; return ()=>{mounted.current=false;}; },[]);
 async function submit(event: FormEvent) {
  event.preventDefault();
  if(active.current) return;
  const parsed=applicantSchema.safeParse({interests,experience});
  if(!parsed.success) {setError(parsed.error.issues[0]?.message ?? 'กรุณาตรวจสอบข้อมูล'); return;}
  active.current=true; setLoading(true); setError(null); setText(null); setCopied(false);
  try {
   const result=await call({data:parsed.data});
   if(mounted.current) {setText(result.text);setError(result.error);queryClient.invalidateQueries({queryKey:['member']});}
  } catch { if(mounted.current) setError('ไม่สามารถเชื่อมต่อได้ ข้อมูลที่กรอกยังอยู่ กรุณาลองใหม่ภายหลัง'); }
  finally { active.current=false; if(mounted.current) setLoading(false); }
 }
 async function copy() { if(!text) return; try {await navigator.clipboard.writeText(text);setCopied(true);} catch {setError('ไม่สามารถคัดลอกได้ กรุณาเลือกข้อความและคัดลอกด้วยตนเอง');} }
 return <section className="section border-t"><div className="site-container"><div className="eyebrow"><Sparkles className="size-4"/>AI RECRUITMENT ADVISOR</div><h2 className="section-title">ค้นหาหน่วยที่เหมาะกับคุณ</h2><Button variant="outline" asChild className="mt-5"><Link to="/auth">ดูคำแนะนำที่บันทึกไว้</Link></Button><div className="mt-8 grid items-start gap-10 lg:grid-cols-2"><form onSubmit={submit} className="space-y-6"><div className="space-y-3"><Label htmlFor="applicant-interests">ความสนใจใน Roblox Roleplay</Label><Textarea id="applicant-interests" value={interests} onChange={e=>setInterests(e.target.value)} disabled={loading} required minLength={10} maxLength={1200} className="min-h-32" placeholder="เช่น ชอบทำภารกิจร่วมกับทีม ฝึกกำลังพล หรือประสานงานกิจกรรม"/><p className="text-right text-xs text-muted-foreground">{interests.length} / 1,200</p></div><div className="space-y-3"><Label htmlFor="applicant-experience">ประสบการณ์และทักษะของคุณ</Label><Textarea id="applicant-experience" value={experience} onChange={e=>setExperience(e.target.value)} disabled={loading} required minLength={10} maxLength={1800} className="min-h-36" placeholder="เล่าประสบการณ์ในเกม หน้าที่ที่เคยทำ และทักษะที่ถนัด หากเพิ่งเริ่มเล่นให้บอกสิ่งที่อยากเรียนรู้"/><p className="text-right text-xs text-muted-foreground">{experience.length} / 1,800</p></div><p className="flex items-start gap-2 text-xs leading-6 text-muted-foreground"><ShieldCheck className="mt-1 size-4 shrink-0"/>ความสนใจ ประสบการณ์ และคำแนะนำจะบันทึกในบัญชีของคุณ ไม่ใช่ใบสมัคร กรุณาไม่ใส่ข้อมูลส่วนตัวหรือรหัสผ่าน</p><Button type="submit" size="lg" disabled={loading} className="w-full sm:w-auto">{loading?<LoaderCircle className="motion-safe:animate-spin"/>:<Sparkles/>}{loading?'กำลังวิเคราะห์ข้อมูล…':'ขอคำแนะนำจาก AI'}{!loading&&<ArrowRight/>}</Button></form><div className="border-l-2 border-primary pl-5 sm:pl-7" aria-live="polite" aria-busy={loading}>{loading?<div role="status" className="py-8"><LoaderCircle className="mb-4 size-7 text-primary motion-safe:animate-spin"/><h3 className="text-lg font-semibold">กำลังเตรียมคำแนะนำของคุณ</h3><p className="mt-3 leading-7 text-muted-foreground">พิจารณาความสนใจ ประสบการณ์ และแนวทางเตรียมใบสมัคร</p></div>:text?<><div className="flex items-center justify-between gap-3"><h3 className="text-lg font-semibold text-primary">คำแนะนำสำหรับคุณ</h3><Button variant="ghost" size="icon" onClick={copy} aria-label={copied?'คัดลอกแล้ว':'คัดลอกคำแนะนำ'} title={copied?'คัดลอกแล้ว':'คัดลอกคำแนะนำ'}>{copied?<Check/>:<Copy/>}</Button></div><div className="mt-5 whitespace-pre-wrap break-words text-sm leading-8">{text}</div></>:<div className="py-7"><Sparkles className="mb-5 size-8 text-primary"/><h3 className="text-lg font-semibold">เส้นทางของคุณใน Mountain Division</h3><p className="mt-4 leading-8 text-muted-foreground">หน่วยปฏิบัติการ · หน่วยฝึก · หน่วยสนับสนุน</p><p className="mt-5 text-xs leading-7 text-muted-foreground">คำแนะนำอ้างอิงโครงสร้างตัวอย่างของหน่วย ไม่ใช่ผลการคัดเลือกหรือการยืนยันตำแหน่งว่าง</p></div>}{error&&<p role="alert" className="mt-5 break-words border border-destructive p-4 text-sm leading-7 text-destructive">{error}</p>}</div></div></div></section>;
}
