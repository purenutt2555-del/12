import { useEffect, useState, type FormEvent } from 'react';
import { Link } from '@tanstack/react-router';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useServerFn } from '@tanstack/react-start';
import { UserRound, LogOut, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { PageHeader } from './content';
import { GoogleSignIn, useMember } from './member-session';
import { getMemberData, updateRobloxName } from '@/lib/member.functions';

export function MemberContent() {
 const { user, ready, signOut } = useMember();
 return <><PageHeader label="MEMBER AREA" title="สมาชิก" description="ชื่อ Roblox และคำแนะนำส่วนตัวของคุณ"/><section className="section site-container">{!ready ? <p role="status">กำลังตรวจสอบบัญชี…</p> : !user ? <div className="space-y-6"><UserRound className="size-9 text-primary"/><h2 className="text-2xl font-semibold">เข้าสู่ระบบสมาชิก</h2><p className="text-muted-foreground">คำแนะนำและชื่อ Roblox จะเห็นได้เฉพาะบัญชีของคุณ</p><GoogleSignIn/></div> : <><div className="mb-8 flex items-center justify-between gap-4"><h2 className="text-xl font-semibold">ข้อมูลสมาชิกของคุณ</h2><Button variant="outline" onClick={() => signOut().catch(() => alert('ออกจากระบบไม่สำเร็จ'))}><LogOut/>ออกจากระบบ</Button></div><MemberDetails key={user.id}/></>}</section></>;
}
function MemberDetails() {
 const load = useServerFn(getMemberData);
 const save = useServerFn(updateRobloxName);
 const client = useQueryClient();
 const { user } = useMember();
 const query = useQuery({ queryKey: ['member', user?.id], queryFn: () => load() });
 const [name, setName] = useState('');
 const [message, setMessage] = useState('');
 const [saving, setSaving] = useState(false);
 useEffect(() => { if (query.data) setName(query.data.profile.roblox_username); }, [query.data?.profile.roblox_username]);
 async function submit(e: FormEvent) {
  e.preventDefault(); setSaving(true); setMessage('');
  try { const result = await save({ data: { username: name } }); setMessage(result.error ?? 'บันทึกชื่อแล้ว'); await client.invalidateQueries({ queryKey: ['member'] }); }
  catch { setMessage('กรุณาใช้ชื่อ Roblox ภาษาอังกฤษ ตัวเลข หรือขีดล่าง 3–20 ตัว'); }
  finally { setSaving(false); }
 }
 if (query.isPending) return <p role="status">กำลังโหลดข้อมูลของคุณ…</p>;
 if (query.isError) return <div role="alert"><p>โหลดข้อมูลสมาชิกไม่สำเร็จ</p><Button className="mt-4" onClick={() => query.refetch()}>ลองใหม่</Button></div>;
 return <div className="grid items-start gap-12 lg:grid-cols-[1fr_2fr]"><form className="space-y-5" onSubmit={submit}><Label htmlFor="roblox-name">ชื่อผู้ใช้ Roblox</Label><Input id="roblox-name" value={name} onChange={e => setName(e.target.value)} minLength={3} maxLength={20} pattern="[A-Za-z0-9_]+" required placeholder="Roblox username"/><p className="text-xs leading-6 text-muted-foreground">ชื่อที่คุณระบุเอง ไม่ใช่การยืนยันบัญชี Roblox</p><Button disabled={saving} type="submit"><Check/>{saving ? 'กำลังบันทึก…' : 'บันทึกชื่อ Roblox'}</Button>{message && <p role="status" className="text-sm">{message}</p>}</form><div className="border-t pt-7 lg:border-l lg:border-t-0 lg:pl-9 lg:pt-0"><h2 className="text-2xl font-semibold">คำแนะนำของฉัน</h2><Button asChild className="my-6"><Link to="/recruitment">ขอคำแนะนำใหม่</Link></Button>{query.data.recommendations.length === 0 ? <p className="text-muted-foreground">ยังไม่มีคำแนะนำที่บันทึกไว้</p> : query.data.recommendations.map(item => <details key={item.id} className="border-b py-5" open={query.data.recommendations[0]?.id === item.id}><summary className="cursor-pointer text-primary">คำแนะนำ · {new Date(item.created_at).toLocaleString('th-TH')}</summary><p className="mt-5 whitespace-pre-wrap break-words text-sm leading-8">{item.recommendation}</p></details>)}</div></div>;
}