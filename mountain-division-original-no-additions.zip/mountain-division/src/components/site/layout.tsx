import { Link } from '@tanstack/react-router';
import { Menu, X, ShieldCheck } from 'lucide-react';
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { BrandMark } from './brand';
import { useMember } from './member-session';
const navigation = [ {to:'/', label:'หน้าหลัก'}, {to:'/history',label:'ประวัติ'}, {to:'/organization',label:'โครงสร้างหน่วย'}, {to:'/news',label:'ข่าวสารและประกาศ'}, {to:'/leadership',label:'ผู้บริหาร'}, {to:'/recruitment',label:'📋 รับสมัคร'} ] as const;
export function SiteHeader() {
 const [open,setOpen]=useState(false);
 const {user}=useMember();
 const items=[...navigation,{to:'/auth' as const,label:user?'บัญชีของฉัน':'เข้าสู่ระบบ'}];
 return <header className="site-header relative z-20"><div className="site-container flex h-full items-center justify-between gap-5"><Link to="/" className="flex items-center gap-3" onClick={()=>setOpen(false)}><BrandMark/><div><div className="brand-name">กองพลทหารภูเขาที่ 1</div><div className="brand-sub mt-1">1ST MOUNTAIN DIVISION</div></div></Link><nav className="hidden items-center gap-4 lg:gap-7 md:flex" aria-label="เมนูหลัก">{items.map(n=><Link key={n.to} to={n.to} activeOptions={{exact:true}} className={n.to==='/recruitment'?'nav-recruit':'nav-link'}>{n.label}</Link>)}</nav><Button variant="ghost" size="icon" className="md:hidden" aria-label={open?'ปิดเมนู':'เปิดเมนู'} aria-expanded={open} onClick={()=>setOpen(!open)}>{open?<X/>:<Menu/>}</Button></div>{open&&<nav className="mobile-nav" aria-label="เมนูมือถือ">{items.map(n=><Link key={n.to} to={n.to} activeOptions={{exact:true}} onClick={()=>setOpen(false)}>{n.label}</Link>)}</nav>}</header>;
}
export function SiteFooter() { return <footer className="footer"><div className="site-container flex flex-col justify-between gap-5 md:flex-row"><div className="flex items-center gap-3"><ShieldCheck className="size-6 text-primary"/><div><span className="font-semibold text-foreground">กองพลทหารภูเขาที่ 1 | Mountain Division</span><p className="mt-2">ชุมชน Roblox Roleplay · ไม่เกี่ยวข้องกับหน่วยงานทหารจริง</p></div></div><div className="md:text-right"><p>วินัย · เกียรติยศ · ความสามัคคี</p><p className="mt-2">© {new Date().getFullYear()} 1st Mountain Division</p></div></div></footer>; }
