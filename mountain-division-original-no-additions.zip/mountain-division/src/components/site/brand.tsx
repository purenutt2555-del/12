export function BrandMark() {
 return <svg className="brand-mark" viewBox="0 0 48 56" fill="none" aria-hidden="true"><path d="M24 2 44 10v23L24 53 4 33V10Z" stroke="currentColor" strokeWidth="1.5"/><path d="m10 33 10-16 6 9 4-6 9 13H10Z" stroke="currentColor" strokeWidth="1.5"/><path d="m17 22 3 3 3-3M27 24l3 3 3-3M15 39h18M20 43h8" stroke="currentColor"/><path d="m24 7 1 3 3 .1-2.4 1.9.8 3-2.4-1.8-2.4 1.8.8-3L19 10.1l3-.1Z" fill="currentColor"/></svg>;
}
