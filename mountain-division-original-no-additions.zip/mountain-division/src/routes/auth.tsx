import { createFileRoute } from '@tanstack/react-router';
import { pageHead } from '@/components/site/content';
import { MemberContent } from '@/components/site/member-content';
export const Route = createFileRoute('/auth')({ head: () => pageHead('สมาชิก', 'เข้าสู่ระบบสมาชิก Mountain Division เก็บชื่อ Roblox และดูคำแนะนำหน่วยเฉพาะบัญชีของคุณ'), component: MemberContent });