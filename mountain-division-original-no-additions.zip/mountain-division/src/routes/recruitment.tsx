import { createFileRoute } from '@tanstack/react-router';
import { RecruitmentContent, pageHead } from '@/components/site/content';
export const Route = createFileRoute('/recruitment')({ head: () => pageHead('รับสมัคร', 'รับสมัครกองพลทหารภูเขาที่ 1 พร้อม AI แนะนำหน่วยและแนวทางเตรียมใบสมัครจากความสนใจใน Roblox Roleplay'), component: RecruitmentContent });
