import { createFileRoute } from '@tanstack/react-router';
import { NewsContent, pageHead } from '@/components/site/content';
export const Route = createFileRoute('/news')({ head: () => pageHead('ข่าวสารและประกาศ', 'ข่าวสารและกิจกรรมของกองพลทหารภูเขาที่ 1'), component: NewsContent });
