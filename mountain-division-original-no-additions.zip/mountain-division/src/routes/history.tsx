import { createFileRoute } from '@tanstack/react-router';
import { HistoryContent, pageHead } from '@/components/site/content';
import { pageTitle, pageDescription } from '@/components/site/history-copy';
export const Route = createFileRoute('/history')({ head: () => pageHead(pageTitle, pageDescription), component: HistoryContent });
