import { createFileRoute } from '@tanstack/react-router';
import { OrganizationContent, pageHead } from '@/components/site/content';
export const Route = createFileRoute('/organization')({ head: () => pageHead('โครงสร้างหน่วย', 'สายการบังคับบัญชาและหน้าที่ใน Mountain Division'), component: OrganizationContent });
