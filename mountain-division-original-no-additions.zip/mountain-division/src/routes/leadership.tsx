import { createFileRoute } from '@tanstack/react-router';
import { LeadershipContent, pageHead } from '@/components/site/content';
export const Route = createFileRoute('/leadership')({ head: () => pageHead('ผู้บริหาร', 'คณะผู้บังคับบัญชาของ Mountain Division'), component: LeadershipContent });
