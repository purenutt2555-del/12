CREATE TABLE public.ai_service_state (service text PRIMARY KEY, status integer NOT NULL, message text NOT NULL, updated_at timestamptz NOT NULL DEFAULT now());
GRANT ALL ON public.ai_service_state TO service_role;
ALTER TABLE public.ai_service_state ENABLE ROW LEVEL SECURITY;
COMMENT ON TABLE public.ai_service_state IS 'Internal AI Gateway pause state. No applicant data. Only trusted server code can access; no browser policies.';